package mphasis;

public class Diamond {

}
