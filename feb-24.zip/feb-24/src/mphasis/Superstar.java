package mphasis;

public class Superstar {
	private static Superstar superstar=new Superstar();			// here creating object is allowed because, private members are available in same class
	private Superstar() {}
	public static Superstar getInstance()
	{
		return superstar;
	}
}