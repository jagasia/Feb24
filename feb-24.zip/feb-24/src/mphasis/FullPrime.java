package mphasis;

import java.util.Scanner;

public class FullPrime {

	public static boolean isPrime(int no)
	{
		//1 is not a prime number
		//2 onwards we need to check
		if(no==1)
			return false;
		for(int i=2;i<=no/2;i++)
		{
			//check if no is divisible by any of 2, 3, 4, until no/2
			//10 is not divisible by 6 or 7 or 8.....	more than half of 10, need not be checked
			if(no%i==0)
				return false;
		}
		return true;
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int start=sc.nextInt();
		int end=sc.nextInt();
		//between these two numbers, we need to find all the prime numbers
		//among those primenumbers which are having all the digits as prime number?
		//in above 2 statements, finding if a number is prime or not is required multiple times. so can we create a method for that?
		boolean isFirst=true;
		for(int i=start;i<=end;i++)
		{
			//get all integers between start and end
			if(isPrime(i))
			{
				//check if each digit is prime or not
				//how to get each digit
				//strategy 1: convert it into string. and then as char array.
				//			then loop each char
				
				//strategy 2:	modulo by 10 gives last digit. divide by 10 removes last digit. repeat until number reduces to 0
				//take a copy of this number
				int copy=i;
				boolean isDigitPrime=true;
				while(copy>0)
				{
					int digit=copy%10;			//gives last digit
					if(!isPrime(digit))
					{
						isDigitPrime=false;
						break;
					}
					copy/=10;
				}
				if(!isDigitPrime)
				{
					continue;
				}else
				{
					if(!isFirst)
						System.out.print(",");
					System.out.print(i);
					isFirst=false;
				}
			}
			
		}
		if(isFirst)
			System.out.println(-1);
	}

}
