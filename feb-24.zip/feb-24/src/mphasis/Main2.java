package mphasis;



public class Main2 {

	{	//this is called as instance block. instance=object
		System.out.println("instance block");
	}
	
	static		//this is called as static initializer block
	{
		System.out.println("This is static block");
	}	
	
	public static void main(String[] args) {
		final int i=20;	//constant		this is allowed. Static is not allowed inside a method
//		Main2 m2=new Main2();
		System.out.println("India");
	}

}
