package mphasis;

public final class Triangle extends Shape {

	public void calculateArea()
	{
		System.out.println("Triangle area is 1/2*breadth*height");
	}

	@Override
	public void draw() {
		System.out.println("Drawing a triangle");
	}
}
