package mphasis;

import java.text.SimpleDateFormat;

public class Main3 {

	public static void main(String[] args) {
		Student rama=new Student();
		rama.method1();
		Student.method2();
		SimpleDateFormat sdf=new SimpleDateFormat();
		
	}

}
