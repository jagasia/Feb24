package mphasis;

public class Student {
	private int studentId;
	String name;
	static String collegeName;
	public Student()
	{
		System.out.println("Student class constructor");
	}
	public void method1()
	{
		System.out.println("Student class Method1 is called");
	}
	public static void method2()
	{
		System.out.println("THis is method 2");
	}
	private void display()
	{
		
	}
}
