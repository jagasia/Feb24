package mphasis;

public class JavaStudent extends Student {
	public JavaStudent()
	{
		System.out.println("Java student constructor");
	}

	public void method1()
	{	
		super.method1();			//only in the first line of a method super is allowed
		System.out.println("Java student method 1 is called");
	}
}
