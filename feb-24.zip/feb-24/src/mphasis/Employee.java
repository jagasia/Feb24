package mphasis;
public class Employee {
	public int employeeId;				//any where
	private String firstName;			//only within this class
	protected String lastName;			//in same package or sub classes of any package
	String address;						//in same package
	
	
}
