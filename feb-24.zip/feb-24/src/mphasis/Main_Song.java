package mphasis;

import java.text.ParseException;
import java.util.Scanner;

public class Main_Song {

	public static void main(String[] args) throws ParseException {
		Scanner sc=new Scanner(System.in);
		String line=sc.nextLine();
		Song song = Song.createSong(line);
		System.out.println(song);
	}

}
