package mphasis;

public class Main_Shape {

	public static void main(String[] args) {
		Shape s=null;		//it is confined to the methods declared in Shape
		s=new Rectange();
		s.calculateArea();	//if calculateArea() is not defined in Shape, it is not available
		s.draw();
		s=new Triangle();
		s.calculateArea();
		s.draw();
	}

}
