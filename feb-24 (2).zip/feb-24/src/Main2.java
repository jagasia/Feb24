

public class Main2 {

	public static void main(String[] args) {
		ContractEmployee cemp=new ContractEmployee();
		cemp.employeeId=1;		//public
		
		
	}

}
