import mphasis.Employee;

public class ContractEmployee extends Employee
{
	public void display()
	{
		employeeId=1;			//public
		lastName="Kumar";		//protected		different package but sub class
//		address="India";		//default
	}
}
