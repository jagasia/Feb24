import mphasis.Employee;

public class Main {

	public static void main(String[] args) {
//		Employee emp=new Employee();
		Employee emp;			//emp is a stack variable. if you see what is inside this variable, a null is found
		emp=new Employee();		//new Employee() is an object created in Heap. Its reference is kept in emp (stack variable)
//		emp.address="123 Main road, New Delhi";				default
		emp.employeeId=1;								//	public
//		emp.lastName="Kumar";								protected
//		emp.firstName="Ram";		//why firstName is not visible here?
	}
}
