package mphasis;

import java.util.Scanner;

public class SmoothArray {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int[] arr = new int[n];
		int a,b,c;
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		
		a=arr[0];
		if(n%2==0)
		{
			//even number of elements
			int x=n/2;
			int y=n/2-1;
			b=arr[x]+arr[y];
		}
		else
		{
			b=arr[n/2];
		}
		
		c=arr[n-1];
		System.out.printf("%d %d %d\n",a,b,c);
		if(a==b && a==c)
			System.out.println("True");
		else
			System.out.println("False");
	}

}
