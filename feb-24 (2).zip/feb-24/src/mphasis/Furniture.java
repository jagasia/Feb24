package mphasis;

import java.util.Scanner;

public class Furniture implements Wood 
{
	private String name;
	private String color;
	public Furniture() {}
	public Furniture(String name, String color) {
		super();
		this.name = name;
		this.color = color;
	}
	@Override
	public String getName() {
		return name;
	}
	@Override
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String getColor() {
		return color;
	}
	@Override
	public void setColor(String color) {
		this.color = color;
	}
	@Override
	public void acceptDetails()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the name:");
		name=sc.nextLine();
		if(name.equals(""))
			name=sc.nextLine();
		System.out.println("Enter the color:");
		this.color=sc.nextLine();
	}
	@Override
	public void displayDetails()
	{
		System.out.println("Name:"+name);
		System.out.println("Color:"+color);
	}
	
	public static void method1()
	{
		
	}
}
