package mphasis;

import java.util.Scanner;

public class EmailValidation {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String email=sc.next();
		String pattern="[a-z]+([.][a-z]+)?[@][a-z]+[.](([a-z]{3})|([a-z]{2}[.][a-z]{2}))";
		if(email.matches(pattern))
			System.out.println("Valid");
		else
			System.out.println("Invalid");
	}

}
