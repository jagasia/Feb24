package mphasis;


interface A
{
	static void display()
	{
		System.out.println("Display method of interface A is called");
	}
	default void speak()
	{
		System.out.println("Interface A speaks");
	}
}

class Aimpl implements A
{
	public void display()
	{
		System.out.println("THis is A display");
	}
	public void speak()
	{		
		System.out.println("My way high way");
	}
}

public class Main4 {

	public static void main(String[] args) {
		Aimpl a=new Aimpl();
		a.display();
		a.speak();
		System.out.println(a instanceof A);
	}

}
