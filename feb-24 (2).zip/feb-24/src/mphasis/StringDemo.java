package mphasis;

import java.util.Scanner;

public class StringDemo {

	public static void main(String[] args) {
		//reverse a string			
		//Palindrome is a String which is equal to its reverse like malayalam
		Scanner sc=new Scanner(System.in);
		String input=sc.next();
		//how to reverse this input string. Lets use StringBuilder
		StringBuilder sb=new StringBuilder();
		sb.append(input);
//		System.out.println(sb); 	//toString is automatically called by sout
		sb.reverse();
//		System.out.println(sb);
		
//		input=sb;			//not allowed
		
		input=sb.toString();		//toString returns the string inside
		System.out.println(input);
		
	
	}

}
