package mphasis;

public class StringBuilderDemo {

	public static void main(String[] args) {
		StringBuilder sb=new StringBuilder("Indian is your country");
		//remove that y
		int index=sb.indexOf("y");
		sb.deleteCharAt(index);
		System.out.println(sb);
	}
}
