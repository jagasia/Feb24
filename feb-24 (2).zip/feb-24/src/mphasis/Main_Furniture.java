package mphasis;

import java.util.Scanner;

public class Main_Furniture {

	public static void main(String[] args) {
//		Chair chair=new Chair();		
//		chair.acceptDetails();
//		chair.displayDetails();
		Wood f=null;			//ref variable of Furniture
		System.out.println("		1: Chair\r\n" + 
				"		2: Book Shelf");
		
		Scanner sc=new Scanner(System.in);
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1:
			f=new Chair();
			break;
		case 2:
			f=new BookShelf();
			break;
		}
		f.acceptDetails();
		f.displayDetails();
	}

}
