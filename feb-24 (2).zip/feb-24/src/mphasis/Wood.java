package mphasis;

public interface Wood {

	String getName();

	void setName(String name);

	String getColor();

	void setColor(String color);

	void acceptDetails();

	void displayDetails();

}