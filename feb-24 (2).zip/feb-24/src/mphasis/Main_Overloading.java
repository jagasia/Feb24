package mphasis;

class Maths
{
	public int sum(int i, int j)
	{
		return i+j;
	}
	public float sum(float i, float j)
	{
		return i+j;
	}
}

public class Main_Overloading {

}
