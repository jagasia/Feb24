package mphasis;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StringExtractNumbers {

	public static void main(String[] args) {
		String str="Please note the number 989898989 and call this number. if it is not working, call 67676767676. ";
		//		[0-9]+		
		//		\\d+
		//		\\d{1,}
		//all the above expressions match with 1 or more digit numbers
		Pattern pattern=Pattern.compile("[0-9]+");
		Matcher matcher = pattern.matcher(str);
		while(matcher.find())
			System.out.println(matcher.group());
	}

}
