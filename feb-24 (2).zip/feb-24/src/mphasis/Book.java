package mphasis;

public class Book {
	
}
