package mphasis;

public class Main_Student {

	public static void main(String[] args) {
		JavaStudent rama=new JavaStudent();		//first Super class object is created. THen only sub class object is created
		rama.method1();
		
		Runtime runtime=Runtime.getRuntime();		//we cannot create an object of Runtime (it is singleton class) Means, there is already 1 instance. we can get that instance
		Superstar x = Superstar.getInstance();		//we have not created object. we obtained the object	
		Superstar y = Superstar.getInstance();
		System.out.println(x);
		System.out.println(y);
	}

}
