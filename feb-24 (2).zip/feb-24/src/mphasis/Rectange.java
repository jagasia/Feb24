package mphasis;

public class Rectange extends Shape{
	public void calculateArea()
	{
		System.out.println("Rectange area is calculated using length * breadth");
	}

	@Override
	public void draw() {
		System.out.println("Drawing a rectangle");
		
	}
//	public void paint()					//the paint method is declared as final in super class. so we cannot override
//	{
//		
//	}
}
