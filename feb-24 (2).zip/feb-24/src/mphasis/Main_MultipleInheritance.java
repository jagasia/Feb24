package mphasis;

interface Person
{
	void speak();
}

class Student implements Person
{

	@Override
	public void speak() {
		System.out.println("Student speaks");
		
	}
	
}

class Teacher implements Person
{

	@Override
	public void speak() {
		System.out.println("Teacher speaks");
		
	}
	
}

public class Main_MultipleInheritance {
	public static void main(String[] args) {
		Person rama;
		rama=new Teacher();
		rama.speak();
		rama=new Student();
		rama.speak();
		
	}
}
