package mphasis;

public class StringReplace {

	public static void main(String[] args) {
		String str="There is a problem. And the problem is not clear. For every problem there is a solution";
		str=str.replaceAll("is", "was");
		System.out.println(str);
	}

}
