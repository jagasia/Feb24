package mphasis;


class SoundBar implements Speaker
{
	public void play()
	{
		System.out.println("Sound bar is playing the song");
	}
}

class HeadPhone implements Speaker
{
	public void play()
	{
		System.out.println("Speaker is playing the song");
	}
}

class EarPhone implements Speaker
{
	public void play()
	{
		System.out.println("Ear Phone is playing the song");
	}	
}

interface Speaker
{
	public void play();			//this is to provide support. it acts as an interface
}

class Mobile
{
	public void playSong(Speaker speaker)
	{
		speaker.play();
	}
}


public class Main {

	public static void main(String[] args) {
		Mobile redmi=new Mobile();
		HeadPhone iball=new HeadPhone();
		EarPhone boat=new EarPhone();
		SoundBar sony=new SoundBar();
		redmi.playSong(sony);
		final int i;
		i=20;
//		i=30;
		System.out.println(i);
	}

}
