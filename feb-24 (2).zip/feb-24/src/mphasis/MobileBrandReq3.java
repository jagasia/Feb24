package mphasis;

import java.util.Scanner;

public class MobileBrandReq3 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String input=sc.nextLine();
		String pattern="#[A-Z]{2,3}( [0-9]{2})? [A-Z0-9]{2,6}-[0-9]{2,4}";
		System.out.println("Reference Id is "+(input.matches(pattern)?"valid":"invalid"));
	}

}
