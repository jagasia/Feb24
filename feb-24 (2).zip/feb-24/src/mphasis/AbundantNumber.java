package mphasis;

import java.util.Scanner;

public class AbundantNumber {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int start=sc.nextInt();
		int end=sc.nextInt();
		boolean isFirst=true;
		int x=-1;
		for(int i=start;i<end;i++)
		{
			int sum=0;
			for(int j=2;j<=i/2;j++)
			{
				//2,3,4,....half of i
				if(i%j==0)
				sum+=j;
			}
			if(sum>i)
			{
				if(!isFirst)
					System.out.print(",");
				System.out.print(i);
				isFirst=false;
			}
		}
		if(isFirst)
			System.out.println(x);
	}

}
