package mphasis;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Song {
	private String title;
	private String genre;
	private Date duration;
	private Double rating;
	public Song() {
		//something is already coded here...
		System.out.println("No arg constructor is invoked");
	}
	
	public Song(String title, String genre) {
		this();
		System.out.println("2 arg constructor is invoked");
		this.title = title;
		this.genre = genre;
	}

	public Song(String title, String genre, Date duration, Double rating) {
		this(title, genre);				//this will call the constructor (without arg) in this case
		System.out.println("4 arg constructor is invoked");
		this.duration = duration;
		this.rating = rating;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	public Date getDuration() {
		return duration;
	}
	public String getDuration1()
	{
		SimpleDateFormat sdf=new SimpleDateFormat("mm:ss");
		return sdf.format(this.duration);
	}
	public void setDuration(Date duration) {
		this.duration = duration;
	}
	public Double getRating() {
		return rating;
	}
	public void setRating(Double rating) {
		this.rating = rating;
	}
	
	@Override
	public String toString() {
		return "Song [title=" + title + ", genre=" + genre + ", duration=" + getDuration1() + ", rating=" + rating + "]";
	}
	static Song createSong(String line) throws ParseException			//this method returns a Song object
	{
		
		String title;
		String genre;
		Date duration;
		Double rating;
		String[] arr = line.split(",");
		title=arr[0];
		genre=arr[1];
		
		SimpleDateFormat sdf=new SimpleDateFormat("mm:ss");		
		duration=sdf.parse(arr[2]);
		
		rating=Double.valueOf(arr[3]);
		
		
		Song song=new Song(title, genre, duration, rating);
		return song;
	}
}
