package mphasis;

import java.util.Scanner;

public class Chair extends Furniture
{
	private int noOfLegs;
	public Chair() {}
	public Chair(int noOfLegs) {
		super();
		this.noOfLegs = noOfLegs;
	}
	public int getNoOfLegs() {
		return noOfLegs;
	}
	public void setNoOfLegs(int noOfLegs) {
		this.noOfLegs = noOfLegs;
	}
	//	public void acceptDetails()		this is a copy obtained from super class
				
	public void acceptDetails()			//this is overriding. Overriding hides the super class method
	{
		super.acceptDetails();			//super class behavior			plus sub class behavior
		Scanner sc=new Scanner(System.in);
		System.out.println("Number  of Legs:");
		noOfLegs=sc.nextInt();
	}
	public void displayDetails()
	{
		super.displayDetails(); 		//only in first line, super is allowed
		System.out.println("Number of Legs:"+noOfLegs);
	}
	
	public static void method1()
	{
		
	}
}
