package mphasis;

interface MyInterface
{
	void doThis();
}

class MyInterfaceImpl implements MyInterface
{
	public void doThis()
	{
		System.out.println("Hello world");
	}
}

public class Main5 {

	public static void main(String[] args) {
//		MyInterface x=new MyInterfaceImpl();
//		x.doThis();
//		MyInterface x=new MyInterface() {
//			
//			@Override
//			public void doThis() {
//				System.out.println("Hi world");
//				
//			}
//		};
//		x.doThis();
		
		MyInterface x=()->{
			System.out.println("Hi this is my lambda implementation");
		};
		x.doThis();
	}
}
