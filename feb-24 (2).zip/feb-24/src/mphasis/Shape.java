package mphasis;

public abstract class Shape {
	private String name;
	private String borderColor;
	private String fillColor;
	public Shape() {}
	public Shape(String name, String borderColor, String fillColor) {
		super();
		this.name = name;
		this.borderColor = borderColor;
		this.fillColor = fillColor;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBorderColor() {
		return borderColor;
	}
	public void setBorderColor(String borderColor) {
		this.borderColor = borderColor;
	}
	public String getFillColor() {
		return fillColor;
	}
	public void setFillColor(String fillColor) {
		this.fillColor = fillColor;
	}
	public abstract void calculateArea();
	
	public abstract void draw();

	public final void paint()
	{
		System.out.println("Painting the shape");
	}
}
